package com.training.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.training.business.bean.PurchaseBean;
import com.training.entity.PurchaseEntity;
import com.training.exceptions.MicroServiceException;
import com.training.web.client.MaterialCategoryConsumer;
import com.training.web.client.MaterialTypeConsumer;
import com.training.web.client.UnitServiceConsumer;

@Repository
public class ReportsDataAccess {

    @Autowired
    private ReportsDAO reportsDAO;

    @Autowired
    private MaterialCategoryConsumer materialCategoryConsumer;

    @Autowired
    private MaterialTypeConsumer materialTypeConsumer;

    @Autowired
    private UnitServiceConsumer unitServiceConsumer;

    public List<PurchaseBean> getVendorWisePurchaseDetails(
            Date from,
            Date to,
            String vendorName) throws MicroServiceException {

        List<PurchaseEntity> purchaseEntities =
                reportsDAO.getVendorWisePurchaseDetails(from, to, vendorName);

        Map<String, String> categoryMap =
                materialCategoryConsumer.getCategoryMap();

        Map<String, String> typeMap =
                materialTypeConsumer.getCategoryTypeMap();

        Map<String, String> unitMap =
                unitServiceConsumer.getUnitMap();

        return purchaseEntities.stream().map(purchaseEntity -> {

            PurchaseBean purchaseBean = new PurchaseBean();

            purchaseBean.setPurchaseId(purchaseEntity.getPurchaseId());
            purchaseBean.setTransactionId(purchaseEntity.getTransactionId());
            purchaseBean.setVendorName(purchaseEntity.getVendorName());
            purchaseBean.setMaterialCategoryId(purchaseEntity.getMaterialCategoryId());
            purchaseBean.setMaterialTypeId(purchaseEntity.getMaterialTypeId());
            purchaseBean.setBrandName(purchaseEntity.getBrandName());
            purchaseBean.setUnitId(purchaseEntity.getUnitId());
            purchaseBean.setQuantity(purchaseEntity.getQuantity());
            purchaseBean.setPurchaseAmount(purchaseEntity.getPurchaseAmount());
            purchaseBean.setPurchaseDate(purchaseEntity.getPurchaseDate());
            purchaseBean.setStatus(purchaseEntity.getStatus());

            purchaseBean.setMaterialCategoryName(
                    categoryMap.get(purchaseEntity.getMaterialCategoryId()));

            purchaseBean.setMaterialTypeName(
                    typeMap.get(purchaseEntity.getMaterialTypeId()));

            purchaseBean.setMaterialUnitName(
                    unitMap.get(purchaseEntity.getUnitId()));

            return purchaseBean;

        }).collect(Collectors.toList());
    }
}