package com.training.test.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.training.controller.MaterialTypeContoller;
import com.training.service.MaterialTypeService;

@WebMvcTest(MaterialTypeContoller.class)
class MaterialTypeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MaterialTypeService materialTypeService;

    @Test
    void getTypeDetailsTest() throws Exception {

        when(materialTypeService.getMaterialTypes())
                .thenReturn(new ArrayList<>());

        mockMvc.perform(
                MockMvcRequestBuilders.get(
                        "/type/controller/getTypeDetails"))
                .andExpect(status().isOk());
    }

    @Test
    void getTypesBasedOnCategoryIdTest() throws Exception {

        when(materialTypeService.getMaterialTypesBasedOnCategoryId("C001"))
                .thenReturn(new ArrayList<>());

        mockMvc.perform(
                MockMvcRequestBuilders.get(
                        "/type/controller/getTypeDetailsByCategoryId/C001"))
                .andExpect(status().isOk());
    }
}