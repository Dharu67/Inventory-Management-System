package com.training.test.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.training.controller.UnitController;
import com.training.service.UnitService;

@WebMvcTest(UnitController.class)
class UnitControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UnitService unitService;

    @Test
    void getUnitDetailsTest() throws Exception {

        when(unitService.getUnits())
                .thenReturn(new ArrayList<>());

        mockMvc.perform(
                MockMvcRequestBuilders.get(
                        "/unit/controller/getUnitDetails"))
                .andExpect(status().isOk());
    }

    @Test
    void getUnitsByCategoryIdTest() throws Exception {

        when(unitService.getUnitsBasedOnCategoryId("C001"))
                .thenReturn(new ArrayList<>());

        mockMvc.perform(
                MockMvcRequestBuilders.get(
                        "/unit/controller/getUnitsByCategoryId/C001"))
                .andExpect(status().isOk());
    }
}