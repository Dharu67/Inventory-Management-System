package com.training.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.business.bean.UnitBean;
import com.training.dao.UnitDAO;
import com.training.entity.MaterialCategoryEntity;
import com.training.entity.UnitEntity;
import com.training.service.UnitServiceImpl;

@ExtendWith(MockitoExtension.class)
class UnitServiceTest {

    @Mock
    private UnitDAO unitDAO;

    @InjectMocks
    private UnitServiceImpl unitService;

    @Test
    void getUnitsBasedOnCategoryIdTest() {

        MaterialCategoryEntity category = new MaterialCategoryEntity();
        category.setCategoryId("C001");

        UnitEntity entity = new UnitEntity();
        entity.setUnitId("U001");
        entity.setUnitName("Kg");
        entity.setMaterialCategoryEntity(category);

        List<UnitEntity> entities = new ArrayList<>();
        entities.add(entity);

        when(unitDAO.findByMaterialCategoryEntityCategoryId("C001"))
                .thenReturn(entities);

        List<UnitBean> result =
                unitService.getUnitsBasedOnCategoryId("C001");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("U001", result.get(0).getUnitId());
        assertEquals("Kg", result.get(0).getUnitName());
        assertEquals("C001", result.get(0).getCategoryId());
    }

    @Test
    void getUnitsBasedOnCategoryIdEmptyTest() {

        when(unitDAO.findByMaterialCategoryEntityCategoryId("C001"))
                .thenReturn(new ArrayList<>());

        List<UnitBean> result =
                unitService.getUnitsBasedOnCategoryId("C001");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getUnitsBasedOnCategoryIdNullTest() {

        when(unitDAO.findByMaterialCategoryEntityCategoryId("C001"))
                .thenReturn(null);

        List<UnitBean> result =
                unitService.getUnitsBasedOnCategoryId("C001");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getUnitsTest() {

        MaterialCategoryEntity category = new MaterialCategoryEntity();
        category.setCategoryId("C001");

        UnitEntity entity = new UnitEntity();
        entity.setUnitId("U001");
        entity.setUnitName("Kg");
        entity.setMaterialCategoryEntity(category);

        List<UnitEntity> entities = new ArrayList<>();
        entities.add(entity);

        when(unitDAO.findAll()).thenReturn(entities);

        List<UnitBean> result = unitService.getUnits();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("U001", result.get(0).getUnitId());
        assertEquals("Kg", result.get(0).getUnitName());
        assertEquals("C001", result.get(0).getCategoryId());
    }

    @Test
    void getUnitsEmptyTest() {

        when(unitDAO.findAll()).thenReturn(new ArrayList<>());

        List<UnitBean> result = unitService.getUnits();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}