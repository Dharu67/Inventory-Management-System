package com.training.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.business.bean.MaterialTypeBean;
import com.training.dao.MaterialTypeDAO;
import com.training.entity.MaterialCategoryEntity;
import com.training.entity.MaterialTypeEntity;
import com.training.service.MaterialTypeServiceImpl;

@ExtendWith(MockitoExtension.class)
class MaterialTypeServiceTest {

    @Mock
    private MaterialTypeDAO materialTypeDAO;

    @InjectMocks
    private MaterialTypeServiceImpl materialTypeService;

    @Test
    void getMaterialTypesBasedOnCategoryIdTest() {

        MaterialCategoryEntity category = new MaterialCategoryEntity();
        category.setCategoryId("C001");

        MaterialTypeEntity entity = new MaterialTypeEntity();
        entity.setTypeId("T001");
        entity.setTypeName("Cotton");
        entity.setMaterialCategoryEntity(category);

        List<MaterialTypeEntity> entities = new ArrayList<>();
        entities.add(entity);

        when(materialTypeDAO.findByMaterialCategoryEntityCategoryId("C001"))
                .thenReturn(entities);

        List<MaterialTypeBean> result =
                materialTypeService.getMaterialTypesBasedOnCategoryId("C001");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("T001", result.get(0).getTypeId());
        assertEquals("Cotton", result.get(0).getTypeName());
        assertEquals("C001", result.get(0).getCategoryId());
    }

    @Test
    void getMaterialTypesBasedOnCategoryIdEmptyTest() {

        when(materialTypeDAO.findByMaterialCategoryEntityCategoryId("C001"))
                .thenReturn(new ArrayList<>());

        List<MaterialTypeBean> result =
                materialTypeService.getMaterialTypesBasedOnCategoryId("C001");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getMaterialTypesBasedOnCategoryIdNullTest() {

        when(materialTypeDAO.findByMaterialCategoryEntityCategoryId("C001"))
                .thenReturn(null);

        List<MaterialTypeBean> result =
                materialTypeService.getMaterialTypesBasedOnCategoryId("C001");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getMaterialTypesTest() {

        MaterialCategoryEntity category = new MaterialCategoryEntity();
        category.setCategoryId("C001");

        MaterialTypeEntity entity = new MaterialTypeEntity();
        entity.setTypeId("T001");
        entity.setTypeName("Cotton");
        entity.setMaterialCategoryEntity(category);

        List<MaterialTypeEntity> entities = new ArrayList<>();
        entities.add(entity);

        when(materialTypeDAO.findAll()).thenReturn(entities);

        List<MaterialTypeBean> result =
                materialTypeService.getMaterialTypes();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("T001", result.get(0).getTypeId());
        assertEquals("Cotton", result.get(0).getTypeName());
        assertEquals("C001", result.get(0).getCategoryId());
    }

    @Test
    void getMaterialTypesEmptyTest() {

        when(materialTypeDAO.findAll()).thenReturn(new ArrayList<>());

        List<MaterialTypeBean> result =
                materialTypeService.getMaterialTypes();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}