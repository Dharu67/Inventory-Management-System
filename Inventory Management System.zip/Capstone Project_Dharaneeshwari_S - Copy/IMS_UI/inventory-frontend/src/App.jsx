import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import PurchaseEntry from "./pages/PurchaseEntry";
import Reports from "./pages/Reports";
import VendorReport from "./pages/VendorReport";

function App() {
  return (
    <BrowserRouter>
      <Routes>

        <Route
          path="/"
          element={<Home />}
        />

        <Route
          path="/purchase-entry"
          element={<PurchaseEntry />}
        />

        <Route
          path="/reports"
          element={<Reports />}
        />

        <Route
          path="/vendor-report"
          element={<VendorReport />}
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;