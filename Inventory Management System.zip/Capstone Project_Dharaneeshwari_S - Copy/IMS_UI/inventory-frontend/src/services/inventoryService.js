import axios from "axios";

const API_BASE_URL = "/api";

export const getVendors = async () => {
  const response = await axios.get(
    `${API_BASE_URL}/vendors`
  );

  return response.data;
};

export const getCategories = async () => {
  const response = await axios.get(
    `${API_BASE_URL}/categories`
  );

  return response.data;
};

export const getUnitAndTypeList = async (materialCategoryId) => {
  const response = await axios.post(
    `${API_BASE_URL}/getUnitAndTypeList`,
    {
      materialCategoryId: materialCategoryId
    }
  );

  return response.data;
};

export const addPurchaseDetail = async (purchaseData) => {
  const response = await axios.post(
    `${API_BASE_URL}/addPurchaseDetail`,
    purchaseData
  );

  return response.data;
};

export const getPurchaseReport = async (reportData) => {
  const response = await axios.post(
    `${API_BASE_URL}/report/controller/getPurchaseDetails`,
    reportData
  );

  return response.data;
};