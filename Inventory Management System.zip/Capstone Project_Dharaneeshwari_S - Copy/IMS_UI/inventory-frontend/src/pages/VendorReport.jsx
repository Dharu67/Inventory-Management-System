import React, { useEffect, useState } from "react";
import {
  getVendors,
  getPurchaseReport,
} from "../services/inventoryService";

const VendorReport = () => {
  const [vendors, setVendors] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [reportData, setReportData] = useState([]);
  const [selectedVendorDetails, setSelectedVendorDetails] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    loadVendors();
  }, []);

  const loadVendors = async () => {
    try {
      const data = await getVendors();
      setVendors(data || []);
    } catch (err) {
      console.error(err);
      setError("Unable to load vendor details.");
    }
  };

  const handleVendorChange = (e) => {
    const vendorName = e.target.value;
    setSelectedVendor(vendorName);

    const vendor = vendors.find(
      (item) => item.vendorName === vendorName
    );

    setSelectedVendorDetails(vendor || null);
    setReportData([]);
    setError("");
  };

  const handleGenerateReport = async () => {
    if (!selectedVendor) {
      setError("Please select a vendor.");
      return;
    }

    if (!fromDate || !toDate) {
      setError("Please select both From Date and To Date.");
      return;
    }

    if (fromDate > toDate) {
      setError("From Date cannot be later than To Date.");
      return;
    }

    try {
      setLoading(true);
      setError("");

      const data = await getPurchaseReport({
        fromDate: fromDate,
        toDate: toDate,
        vendorName: selectedVendor,
      });

      setReportData(data || []);
    } catch (err) {
      console.error(err);
      setError("Unable to generate purchase report.");
      setReportData([]);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateValue) => {
    if (!dateValue) return "-";

    const date = new Date(dateValue);

    if (isNaN(date.getTime())) {
      return dateValue;
    }

    return date.toLocaleDateString("en-GB");
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#f1f5f9",
        padding: "40px 20px",
        boxSizing: "border-box",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <div
        style={{
          maxWidth: "1250px",
          margin: "0 auto",
        }}
      >
        {/* PAGE TITLE */}
        <div
          style={{
            marginBottom: "30px",
            textAlign: "center",
          }}
        >
          <h1
            style={{
              margin: "0 0 8px 0",
              color: "#17365d",
              fontSize: "32px",
              fontWeight: "700",
            }}
          >
            Vendor Purchase Report
          </h1>

          <p
            style={{
              margin: 0,
              color: "#64748b",
              fontSize: "15px",
            }}
          >
            Generate purchase details for a selected vendor and date range
          </p>
        </div>

        {/* FILTER CARD */}
        <div
          style={{
            background: "#ffffff",
            border: "1px solid #cbd5e1",
            borderRadius: "12px",
            padding: "25px",
            marginBottom: "25px",
            boxShadow: "0 3px 10px rgba(0,0,0,0.06)",
          }}
        >
          <h2
            style={{
              margin: "0 0 20px 0",
              color: "#17365d",
              fontSize: "20px",
            }}
          >
            Report Filters
          </h2>

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "minmax(220px, 1.5fr) minmax(180px, 1fr) minmax(180px, 1fr) auto",
              gap: "18px",
              alignItems: "end",
            }}
          >
            {/* VENDOR */}
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "7px",
                  fontWeight: "600",
                  color: "#334155",
                  fontSize: "14px",
                }}
              >
                Vendor
              </label>

              <select
                value={selectedVendor}
                onChange={handleVendorChange}
                style={{
                  width: "100%",
                  height: "44px",
                  padding: "0 12px",
                  border: "1px solid #94a3b8",
                  borderRadius: "7px",
                  fontSize: "14px",
                  color: "#334155",
                  background: "#ffffff",
                  boxSizing: "border-box",
                  outline: "none",
                }}
              >
                <option value="">Select Vendor</option>

                {vendors.map((vendor) => (
                  <option
                    key={vendor.vendorId}
                    value={vendor.vendorName}
                  >
                    {vendor.vendorName}
                  </option>
                ))}
              </select>
            </div>

            {/* FROM DATE */}
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "7px",
                  fontWeight: "600",
                  color: "#334155",
                  fontSize: "14px",
                }}
              >
                From Date
              </label>

              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                style={{
                  width: "100%",
                  height: "44px",
                  padding: "0 12px",
                  border: "1px solid #94a3b8",
                  borderRadius: "7px",
                  fontSize: "14px",
                  color: "#334155",
                  boxSizing: "border-box",
                }}
              />
            </div>

            {/* TO DATE */}
            <div>
              <label
                style={{
                  display: "block",
                  marginBottom: "7px",
                  fontWeight: "600",
                  color: "#334155",
                  fontSize: "14px",
                }}
              >
                To Date
              </label>

              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                style={{
                  width: "100%",
                  height: "44px",
                  padding: "0 12px",
                  border: "1px solid #94a3b8",
                  borderRadius: "7px",
                  fontSize: "14px",
                  color: "#334155",
                  boxSizing: "border-box",
                }}
              />
            </div>

            {/* BUTTON */}
            <button
              onClick={handleGenerateReport}
              disabled={loading}
              style={{
                height: "44px",
                padding: "0 22px",
                border: "none",
                borderRadius: "7px",
                background: "#1e3a5f",
                color: "#ffffff",
                fontSize: "14px",
                fontWeight: "600",
                cursor: loading ? "not-allowed" : "pointer",
                whiteSpace: "nowrap",
                opacity: loading ? 0.7 : 1,
              }}
            >
              {loading ? "Generating..." : "Generate Report"}
            </button>
          </div>

          {/* ERROR */}
          {error && (
            <div
              style={{
                marginTop: "18px",
                padding: "12px 15px",
                borderRadius: "7px",
                background: "#fef2f2",
                border: "1px solid #fecaca",
                color: "#b91c1c",
                fontSize: "14px",
              }}
            >
              {error}
            </div>
          )}
        </div>

        {/* VENDOR DETAILS */}
        {selectedVendorDetails && (
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderRadius: "12px",
              padding: "25px",
              marginBottom: "25px",
              boxShadow: "0 3px 10px rgba(0,0,0,0.06)",
            }}
          >
            <h2
              style={{
                margin: "0 0 20px 0",
                color: "#17365d",
                fontSize: "20px",
              }}
            >
              Vendor Details
            </h2>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(220px, 1fr))",
                gap: "15px",
              }}
            >
              <div
                style={{
                  background: "#eef2f7",
                  border: "1px solid #cbd5e1",
                  borderRadius: "8px",
                  padding: "15px",
                }}
              >
                <div
                  style={{
                    color: "#64748b",
                    fontSize: "13px",
                    marginBottom: "6px",
                    fontWeight: "600",
                  }}
                >
                  Vendor Name
                </div>

                <div
                  style={{
                    color: "#17365d",
                    fontSize: "15px",
                    fontWeight: "700",
                  }}
                >
                  {selectedVendorDetails.vendorName || "-"}
                </div>
              </div>

              <div
                style={{
                  background: "#eef2f7",
                  border: "1px solid #cbd5e1",
                  borderRadius: "8px",
                  padding: "15px",
                }}
              >
                <div
                  style={{
                    color: "#64748b",
                    fontSize: "13px",
                    marginBottom: "6px",
                    fontWeight: "600",
                  }}
                >
                  Contact Person
                </div>

                <div
                  style={{
                    color: "#17365d",
                    fontSize: "15px",
                    fontWeight: "700",
                  }}
                >
                  {selectedVendorDetails.contactPerson || "-"}
                </div>
              </div>

              <div
                style={{
                  background: "#eef2f7",
                  border: "1px solid #cbd5e1",
                  borderRadius: "8px",
                  padding: "15px",
                }}
              >
                <div
                  style={{
                    color: "#64748b",
                    fontSize: "13px",
                    marginBottom: "6px",
                    fontWeight: "600",
                  }}
                >
                  Contact Number
                </div>

                <div
                  style={{
                    color: "#17365d",
                    fontSize: "15px",
                    fontWeight: "700",
                  }}
                >
                  {selectedVendorDetails.contactNumber || "-"}
                </div>
              </div>

              <div
                style={{
                  background: "#eef2f7",
                  border: "1px solid #cbd5e1",
                  borderRadius: "8px",
                  padding: "15px",
                }}
              >
                <div
                  style={{
                    color: "#64748b",
                    fontSize: "13px",
                    marginBottom: "6px",
                    fontWeight: "600",
                  }}
                >
                  Vendor Address
                </div>

                <div
                  style={{
                    color: "#17365d",
                    fontSize: "15px",
                    fontWeight: "700",
                    lineHeight: "1.5",
                  }}
                >
                  {selectedVendorDetails.vendorAddress || "-"}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PURCHASE REPORT */}
        {selectedVendor && reportData.length > 0 && (
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderRadius: "12px",
              padding: "25px",
              boxShadow: "0 3px 10px rgba(0,0,0,0.06)",
              overflowX: "auto",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "20px",
                gap: "15px",
                flexWrap: "wrap",
              }}
            >
              <div>
                <h2
                  style={{
                    margin: 0,
                    color: "#17365d",
                    fontSize: "20px",
                  }}
                >
                  Purchase Details
                </h2>

                <p
                  style={{
                    margin: "5px 0 0 0",
                    color: "#64748b",
                    fontSize: "13px",
                  }}
                >
                  {selectedVendor} | {formatDate(fromDate)} -{" "}
                  {formatDate(toDate)}
                </p>
              </div>

              <div
                style={{
                  background: "#1e3a5f",
                  color: "#ffffff",
                  padding: "8px 14px",
                  borderRadius: "20px",
                  fontSize: "13px",
                  fontWeight: "600",
                }}
              >
                {reportData.length} Purchase
                {reportData.length !== 1 ? "s" : ""}
              </div>
            </div>

            <div
              style={{
                overflowX: "auto",
                border: "1px solid #cbd5e1",
                borderRadius: "8px",
              }}
            >
              <table
                style={{
                  width: "100%",
                  borderCollapse: "collapse",
                  minWidth: "1000px",
                  fontSize: "13px",
                }}
              >
                <thead>
                  <tr
                    style={{
                      background: "#1e3a5f",
                      color: "#ffffff",
                    }}
                  >
                    <th
                      style={{
                        padding: "13px 10px",
                        textAlign: "center",
                        borderRight: "1px solid #17365d",
                      }}
                    >
                      S.No
                    </th>

                    <th
                      style={{
                        padding: "13px 10px",
                        textAlign: "left",
                        borderRight: "1px solid #17365d",
                      }}
                    >
                      Material Category
                    </th>

                    <th
                      style={{
                        padding: "13px 10px",
                        textAlign: "left",
                        borderRight: "1px solid #17365d",
                      }}
                    >
                      Material Type
                    </th>

                    <th
                      style={{
                        padding: "13px 10px",
                        textAlign: "left",
                        borderRight: "1px solid #17365d",
                      }}
                    >
                      Brand
                    </th>

                    <th
                      style={{
                        padding: "13px 10px",
                        textAlign: "left",
                        borderRight: "1px solid #17365d",
                      }}
                    >
                      Unit
                    </th>

                    <th
                      style={{
                        padding: "13px 10px",
                        textAlign: "right",
                        borderRight: "1px solid #17365d",
                      }}
                    >
                      Quantity
                    </th>

                    <th
                      style={{
                        padding: "13px 10px",
                        textAlign: "right",
                        borderRight: "1px solid #17365d",
                      }}
                    >
                      Purchase Amount
                    </th>

                    <th
                      style={{
                        padding: "13px 10px",
                        textAlign: "center",
                        borderRight: "1px solid #17365d",
                      }}
                    >
                      Purchase Date
                    </th>

                    <th
                      style={{
                        padding: "13px 10px",
                        textAlign: "center",
                      }}
                    >
                      Status
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {reportData.map((item, index) => (
                    <tr
                      key={
                        item.purchaseId ||
                        `${item.transactionId}-${index}`
                      }
                      style={{
                        background:
                          index % 2 === 0 ? "#ffffff" : "#f8fafc",
                        borderBottom: "1px solid #e2e8f0",
                      }}
                    >
                      <td
                        style={{
                          padding: "12px 10px",
                          textAlign: "center",
                          color: "#475569",
                          fontWeight: "600",
                        }}
                      >
                        {index + 1}
                      </td>

                      <td
                        style={{
                          padding: "12px 10px",
                          color: "#334155",
                        }}
                      >
                        {item.materialCategoryName ||
                          item.materialCategoryId ||
                          "-"}
                      </td>

                      <td
                        style={{
                          padding: "12px 10px",
                          color: "#334155",
                        }}
                      >
                        {item.materialTypeName ||
                          item.materialTypeId ||
                          "-"}
                      </td>

                      <td
                        style={{
                          padding: "12px 10px",
                          color: "#334155",
                        }}
                      >
                        {item.brandName || "-"}
                      </td>

                      <td
                        style={{
                          padding: "12px 10px",
                          color: "#334155",
                        }}
                      >
                        {item.materialUnitName ||
                          item.unitId ||
                          "-"}
                      </td>

                      <td
                        style={{
                          padding: "12px 10px",
                          textAlign: "right",
                          color: "#334155",
                        }}
                      >
                        {item.quantity ?? "-"}
                      </td>

                      <td
                        style={{
                          padding: "12px 10px",
                          textAlign: "right",
                          color: "#334155",
                          fontWeight: "600",
                        }}
                      >
                        {item.purchaseAmount != null
                          ? Number(item.purchaseAmount).toFixed(2)
                          : "-"}
                      </td>

                      <td
                        style={{
                          padding: "12px 10px",
                          textAlign: "center",
                          color: "#334155",
                        }}
                      >
                        {formatDate(item.purchaseDate)}
                      </td>

                      <td
                        style={{
                          padding: "12px 10px",
                          textAlign: "center",
                        }}
                      >
                        <span
                          style={{
                            display: "inline-block",
                            padding: "5px 10px",
                            borderRadius: "15px",
                            background:
                              item.status === "SUCCESS"
                                ? "#dcfce7"
                                : "#f1f5f9",
                            color:
                              item.status === "SUCCESS"
                                ? "#166534"
                                : "#475569",
                            fontWeight: "600",
                            fontSize: "12px",
                          }}
                        >
                          {item.status || "-"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* NO DATA */}
        {selectedVendor &&
          !loading &&
          reportData.length === 0 &&
          !error && (
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #cbd5e1",
                borderRadius: "12px",
                padding: "40px 20px",
                textAlign: "center",
                color: "#64748b",
                boxShadow: "0 3px 10px rgba(0,0,0,0.05)",
              }}
            >
              <div
                style={{
                  fontSize: "18px",
                  fontWeight: "600",
                  color: "#475569",
                  marginBottom: "8px",
                }}
              >
                No purchase records found
              </div>

              <div style={{ fontSize: "14px" }}>
                No purchases were found for the selected vendor and
                date range.
              </div>
            </div>
          )}
      </div>
    </div>
  );
};

export default VendorReport;