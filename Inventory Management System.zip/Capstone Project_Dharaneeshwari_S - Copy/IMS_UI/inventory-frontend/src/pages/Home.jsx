import { useNavigate } from "react-router-dom";
import "../index.css";

function Home() {
  const navigate = useNavigate();

  return (
    <div className="app">
      
      <header className="navbar">
        <div className="logo">
          Inventory Management System
        </div>

        <nav>
          <a href="/">Home</a>
          <a href="/purchase-entry">Entry</a>
          <a href="/reports">Report</a>
        </nav>
      </header>

      <main className="home-content">

        <section className="hero">
          <h1>Inventory Management System</h1>

          <p>
            Manage vendors, materials, purchases and inventory
            efficiently from one place.
          </p>

          <button
            type="button"
            onClick={() => navigate("/purchase-entry")}
          >
            Get Started
          </button>
        </section>

        <section className="cards">

          <div className="card">
            <h2>Vendors</h2>
            <p>Manage vendor information and details.</p>
          </div>

          <div className="card">
            <h2>Materials</h2>
            <p>Manage materials and their categories.</p>
          </div>

          <div className="card">
            <h2>Inventory</h2>
            <p>Track purchases and available inventory.</p>
          </div>

        </section>

      </main>

      <footer>
        <p>Inventory Management System © 2026</p>
      </footer>

    </div>
  );
}

export default Home;