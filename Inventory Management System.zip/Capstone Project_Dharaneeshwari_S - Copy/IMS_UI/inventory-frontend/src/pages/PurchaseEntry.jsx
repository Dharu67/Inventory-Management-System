import { useEffect, useState } from "react";
import "../index.css";

import {
  getVendors,
  getCategories,
  getUnitAndTypeList,
  addPurchaseDetail,
} from "../services/inventoryService";

function PurchaseEntry() {
  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [materialTypes, setMaterialTypes] = useState([]);
  const [units, setUnits] = useState([]);

  const [formData, setFormData] = useState({
    vendorName: "",
    materialCategoryId: "",
    materialTypeId: "",
    unitId: "",
    brandName: "",
    quantity: "",
    purchaseAmount: "",
    purchaseDate: "",
  });

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const vendorData = await getVendors();
        const categoryData = await getCategories();

        setVendors(vendorData);
        setCategories(categoryData);
      } catch (err) {
        console.error(err);

        setError(
          "Unable to load vendors or material categories."
        );
      }
    };

    loadInitialData();
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;

    setFormData((previousData) => ({
      ...previousData,
      [name]: value,
    }));

    setMessage("");
    setError("");
  };

  const handleCategoryChange = async (event) => {
    const categoryId = event.target.value;

    setFormData((previousData) => ({
      ...previousData,
      materialCategoryId: categoryId,
      materialTypeId: "",
      unitId: "",
    }));

    setMaterialTypes([]);
    setUnits([]);

    setMessage("");
    setError("");

    if (!categoryId) {
      return;
    }

    try {
      const data = await getUnitAndTypeList(categoryId);

      setMaterialTypes(data.materialTypeList || []);
      setUnits(data.unitList || []);
    } catch (err) {
      console.error(err);

      setError(
        "Unable to load material type and unit details."
      );
    }
  };

  const resetForm = () => {
    setFormData({
      vendorName: "",
      materialCategoryId: "",
      materialTypeId: "",
      unitId: "",
      brandName: "",
      quantity: "",
      purchaseAmount: "",
      purchaseDate: "",
    });

    setMaterialTypes([]);
    setUnits([]);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    setMessage("");
    setError("");
    setLoading(true);

    try {
      const purchaseData = {
        vendorName: formData.vendorName,
        materialCategoryId: formData.materialCategoryId,
        materialTypeId: formData.materialTypeId,
        unitId: formData.unitId,
        brandName: formData.brandName,
        quantity: Number(formData.quantity),
        purchaseAmount: Number(formData.purchaseAmount),
        purchaseDate: formData.purchaseDate,
      };

      const response = await addPurchaseDetail(purchaseData);

      if (response.status === "SUCCESS") {
        setMessage(
          response.message || "Purchase added successfully!"
        );

        resetForm();
      } else {
        setError(
          response.message || "Purchase could not be added."
        );
      }
    } catch (err) {
      console.error(err);

      if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else {
        setError(
          "Unable to submit purchase. Please check whether the Inventory Service is running."
        );
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="purchase-page">

      <header className="navbar">
        <div className="logo">
          Inventory Management System
        </div>

        <nav>
          <a href="/">Home</a>
          <a href="/purchase-entry">Entry</a>
          <a href="/reports">Report</a>
        </nav>
      </header>

      <main className="purchase-content">

        <section className="purchase-header">
          <h1>Material Purchase Entry</h1>

          <p>
            Enter the details of a new material purchase.
          </p>
        </section>

        {message && (
          <div className="success-message purchase-message">
            <strong>✓ Purchase Successful</strong>
            <br />
            {message}
          </div>
        )}

        {error && (
          <div className="error-message purchase-message">
            {error}
          </div>
        )}

        <section className="purchase-card">

          <h2>Purchase Details</h2>

          <form
            className="purchase-form"
            onSubmit={handleSubmit}
          >

            <div className="form-group">
              <label>Vendor Name</label>

              <select
                name="vendorName"
                value={formData.vendorName}
                onChange={handleChange}
                required
              >
                <option value="">
                  Select Vendor
                </option>

                {vendors.map((vendor) => (
                  <option
                    key={vendor.vendorId}
                    value={vendor.vendorName}
                  >
                    {vendor.vendorName}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Material Category</label>

              <select
                name="materialCategoryId"
                value={formData.materialCategoryId}
                onChange={handleCategoryChange}
                required
              >
                <option value="">
                  Select Category
                </option>

                {categories.map((category) => (
                  <option
                    key={category.categoryId}
                    value={category.categoryId}
                  >
                    {category.categoryName}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Material Type</label>

              <select
                name="materialTypeId"
                value={formData.materialTypeId}
                onChange={handleChange}
                disabled={!formData.materialCategoryId}
                required
              >
                <option value="">
                  Select Material Type
                </option>

                {materialTypes.map((type) => (
                  <option
                    key={type.typeId}
                    value={type.typeId}
                  >
                    {type.typeName}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Unit</label>

              <select
                name="unitId"
                value={formData.unitId}
                onChange={handleChange}
                disabled={!formData.materialCategoryId}
                required
              >
                <option value="">
                  Select Unit
                </option>

                {units.map((unit) => (
                  <option
                    key={unit.unitId}
                    value={unit.unitId}
                  >
                    {unit.unitName}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Brand Name</label>

              <input
                type="text"
                name="brandName"
                value={formData.brandName}
                onChange={handleChange}
                placeholder="Enter brand name"
                required
              />
            </div>

            <div className="form-group">
              <label>Quantity</label>

              <input
                type="number"
                name="quantity"
                value={formData.quantity}
                onChange={handleChange}
                placeholder="Enter quantity"
                min="1"
                required
              />
            </div>

            <div className="form-group">
              <label>Purchase Amount (₹)</label>

              <input
                type="number"
                name="purchaseAmount"
                value={formData.purchaseAmount}
                onChange={handleChange}
                placeholder="Enter purchase amount"
                min="0"
                step="0.01"
                required
              />
            </div>

            <div className="form-group">
              <label>Purchase Date</label>

              <input
                type="date"
                name="purchaseDate"
                value={formData.purchaseDate}
                onChange={handleChange}
                required
              />
            </div>

            <button
              type="submit"
              className="submit-button"
              disabled={loading}
            >
              {loading ? "Submitting..." : "Submit Purchase"}
            </button>

          </form>

        </section>

      </main>

      <footer>
        <p>Inventory Management System © 2026</p>
      </footer>

    </div>
  );
}

export default PurchaseEntry;