import { Link } from "react-router-dom";

function Reports() {
  return (
    <div className="report-page">
      <header className="navbar">
        <div className="logo">Inventory Management System</div>

        <nav>
          <a href="/">Home</a>
          <a href="/purchase-entry">Entry</a>
          <a href="/reports">Report</a>
        </nav>
      </header>

      <main className="report-content">
        <section className="report-header">
          <h1>Reports</h1>
          <p>
            View purchase reports and analyze inventory transactions.
          </p>
        </section>

        <section className="report-form-card">
          <h2>Vendor Purchase Report</h2>

          <p>
            View purchase details for a selected vendor within a
            specified date range.
          </p>

          <Link
            to="/vendor-report"
            className="report-button"
            style={{
              display: "inline-block",
              textDecoration: "none",
              marginTop: "15px"
            }}
          >
            View Vendor Report
          </Link>
        </section>
      </main>

      <footer>
        <p>Inventory Management System © 2026</p>
      </footer>
    </div>
  );
}

export default Reports;