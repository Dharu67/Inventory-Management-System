import { Link } from "react-router-dom";

function Navbar() {
  return (
    <header className="navbar">
      <div className="logo">
        Inventory Management System
      </div>

      <nav>
        <Link to="/">Home</Link>
        <Link to="/purchase-entry">Entry</Link>
        <Link to="/reports">Report</Link>
      </nav>
    </header>
  );
}

export default Navbar;