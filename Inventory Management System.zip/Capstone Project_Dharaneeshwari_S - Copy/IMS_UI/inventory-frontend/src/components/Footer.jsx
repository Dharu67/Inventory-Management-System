function Footer() {
  return (
    <footer>
      <p>Inventory Management System © 2026</p>
    </footer>
  );
}

export default Footer;